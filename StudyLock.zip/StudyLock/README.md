# StudyLock (Android)

Floating study timer + lock-in mode.

- Timer runs only while the screen is on and a **study app** (default: Physics Wallah, YouTube) is in the foreground. Otherwise it pauses (grey bubble).
- Lock-in: for 25/45/60/90/120 min, every app except your study apps, phone dialer and home screen is covered and you are sent home.
- Emergency exit: type a long sentence in the app.

## Build
1. Install Android Studio. File > Open > select this `StudyLock` folder. Let Gradle sync.
2. Connect your phone (USB debugging on) and press Run, or Build > Build APK(s).
3. On the phone, open StudyLock and grant: Floating window + Usage access.
4. Tap "Choose study apps" and tick your PW app and YouTube (verify the PW package is ticked).
5. Tap "Start floating timer". Drag the bubble anywhere.

## Known limits
- Android only (iPhone does not allow floating overlays or app detection).
- Cannot tell a YouTube lecture from other YouTube videos; all YouTube time counts.
- A determined user can still force-stop the app or revoke permissions in Settings.
- Some phones (Xiaomi, Oppo, Vivo, Samsung) kill background services: set battery to "Unrestricted" for StudyLock.

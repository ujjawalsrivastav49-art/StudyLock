package com.studylock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Floating timer + focus lock.
 *  - Timer only advances while the screen is on AND a study app is in the foreground.
 *  - While a lock-in session is active, any non-allowed app is covered and the user is sent home.
 */
class FocusService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL = "studylock"

        fun start(c: Context) {
            c.startForegroundService(Intent(c, FocusService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, FocusService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var usm: UsageStatsManager
    private lateinit var pm: PowerManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var blocker: View? = null
    private var blockerMsg: TextView? = null

    private var lastPkg: String? = null
    private var lastQuery = 0L
    private var lastTick = 0L
    private var tickCount = 0
    private var wentHomeFor: String? = null

    private var studyApps: Set<String> = emptySet()
    private var allowed: Set<String> = emptySet()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        pm = getSystemService(POWER_SERVICE) as PowerManager

        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "StudyLock", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("StudyLock is running")
            .setContentText("Timer counts only while you study")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        try {
            addBubble()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        loadConfig()
        lastTick = SystemClock.elapsedRealtime()
        lastQuery = System.currentTimeMillis() - 10_000
        handler.post(tick)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        bubble?.let { runCatching { wm.removeView(it) } }
        blocker?.let { runCatching { wm.removeView(it) } }
        bubble = null
        blocker = null
        super.onDestroy()
    }

    // ---------- main loop ----------

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val dt = (now - lastTick).coerceIn(0, 2000)
            lastTick = now
            if (tickCount++ % 20 == 0) loadConfig()

            val pkg = foreground()
            val interactive = pm.isInteractive
            val studying = interactive && pkg != null && pkg in studyApps

            var total = Prefs.todayMs(this@FocusService)
            if (studying) {
                total += dt
                Prefs.setTodayMs(this@FocusService, total)
            }

            val left = Prefs.lockUntil(this@FocusService) - System.currentTimeMillis()
            val locked = left > 0

            if (locked && interactive && pkg != null && !isAllowed(pkg)) {
                showBlocker(left)
                if (wentHomeFor != pkg) {
                    wentHomeFor = pkg
                    goHome()
                }
            } else {
                hideBlocker()
                if (pkg == null || isAllowed(pkg)) wentHomeFor = null
            }

            updateBubble(total, studying, if (locked) left else 0L)
            handler.postDelayed(this, 500)
        }
    }

    private fun loadConfig() {
        studyApps = Prefs.studyApps(this)
        val set = mutableSetOf(
            "com.android.systemui", "android",
            "com.google.android.dialer", "com.android.dialer",
            "com.android.incallui", "com.samsung.android.incallui"
        )
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            Intent(Intent.ACTION_DIAL)
        )
        for (i in intents) {
            packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
                .forEach { set.add(it.activityInfo.packageName) }
        }
        allowed = set
    }

    private fun isAllowed(pkg: String) =
        pkg == packageName || pkg in studyApps || pkg in allowed

    @Suppress("DEPRECATION")
    private fun foreground(): String? {
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(lastQuery - 1000, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastPkg = e.packageName
        }
        lastQuery = now
        return lastPkg
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------- floating bubble ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addBubble() {
        val tv = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(10), dp(16), dp(10))
            text = "0:00:00"
            background = GradientDrawable().apply {
                cornerRadius = dp(30).toFloat()
                setColor(Color.parseColor("#475569"))
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx
                        val dy = e.rawY - ty
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        startActivity(
                            Intent(this@FocusService, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                return true
            }
        })
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun updateBubble(total: Long, studying: Boolean, lockLeft: Long) {
        val b = bubble ?: return
        val prefix = if (lockLeft > 0) "🔒 " else ""
        val suffix = if (studying) "" else "  ⏸"
        b.text = prefix + Prefs.fmt(total) + suffix
        (b.background as GradientDrawable)
            .setColor(Color.parseColor(if (studying) "#16A34A" else "#475569"))
    }

    // ---------- distraction blocker ----------

    private fun showBlocker(leftMs: Long) {
        val mins = (leftMs / 60_000) + 1
        if (blocker == null) {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#F20F172A"))
                setPadding(dp(32), dp(32), dp(32), dp(32))
                isClickable = true
            }
            val title = TextView(this).apply {
                text = "🔒 Locked in"
                textSize = 28f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            val msg = TextView(this).apply {
                textSize = 18f
                setTextColor(Color.parseColor("#CBD5E1"))
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(24))
            }
            val btn = Button(this).apply {
                text = "Back to study"
                setOnClickListener { openStudyApp() }
            }
            root.addView(title)
            root.addView(msg)
            root.addView(btn)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            runCatching { wm.addView(root, lp) }.onSuccess {
                blocker = root
                blockerMsg = msg
            }
        }
        blockerMsg?.text = "This app is blocked.\n$mins min of focus left."
    }

    private fun hideBlocker() {
        blocker?.let { runCatching { wm.removeView(it) } }
        blocker = null
        blockerMsg = null
    }

    private fun openStudyApp() {
        for (p in studyApps) {
            val i = packageManager.getLaunchIntentForPackage(p) ?: continue
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        goHome()
    }
}

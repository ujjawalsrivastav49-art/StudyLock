package com.studylock

import android.content.Context
import java.time.LocalDate

object Prefs {
    // Physics Wallah + YouTube. Change the list inside the app ("Choose study apps").
    val DEFAULT_STUDY = setOf("xyz.penpencil.physicswala", "com.google.android.youtube")

    private fun sp(c: Context) = c.getSharedPreferences("studylock", Context.MODE_PRIVATE)

    fun studyApps(c: Context): Set<String> =
        sp(c).getStringSet("study", DEFAULT_STUDY)!!.toSet()

    fun setStudyApps(c: Context, s: Set<String>) {
        sp(c).edit().putStringSet("study", s).apply()
    }

    fun todayMs(c: Context): Long {
        val p = sp(c)
        val today = LocalDate.now().toString()
        if (p.getString("day", null) != today) {
            p.edit().putString("day", today).putLong("ms", 0).apply()
            return 0
        }
        return p.getLong("ms", 0)
    }

    fun setTodayMs(c: Context, ms: Long) {
        sp(c).edit().putString("day", LocalDate.now().toString()).putLong("ms", ms).apply()
    }

    fun lockUntil(c: Context): Long = sp(c).getLong("lockUntil", 0)

    fun setLockUntil(c: Context, t: Long) {
        sp(c).edit().putLong("lockUntil", t).apply()
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }
}

package com.studylock

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private val phrase = "I choose to quit my study session"

    private lateinit var timeTv: TextView
    private lateinit var permTv: TextView
    private lateinit var lockTv: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnUsage: Button
    private lateinit var toggleBtn: Button
    private lateinit var durRow: LinearLayout
    private lateinit var emergency: LinearLayout
    private lateinit var phraseEt: EditText

    private val refresh = object : Runnable {
        override fun run() {
            render()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, bold: Boolean = false, color: String = "#0F172A") =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(t: String, onClick: () -> Unit) =
        Button(this).apply {
            text = t
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        root.addView(text("StudyLock", 26f, true))
        root.addView(text("Studied today", 14f, color = "#64748B"))
        timeTv = text("0:00:00", 44f, true, "#16A34A")
        root.addView(timeTv)

        permTv = text("", 14f)
        root.addView(permTv)
        btnOverlay = button("Allow floating window") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btnUsage = button("Allow usage access (to detect PW / YouTube)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        root.addView(btnOverlay)
        root.addView(btnUsage)

        toggleBtn = button("Start floating timer") { toggleService() }
        root.addView(toggleBtn)
        root.addView(button("Choose study apps") { pickApps() })

        root.addView(text("Lock-in", 20f, true).apply { setPadding(0, dp(24), 0, dp(6)) })
        lockTv = text("Block every other app for a set time.", 14f, color = "#64748B")
        root.addView(lockTv)

        durRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in listOf(25, 45, 60, 90, 120)) {
            val b = button("$m m") { startLock(m) }
            durRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(durRow)

        emergency = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emergency.addView(text("Emergency exit — type exactly:\n\"$phrase\"", 13f, color = "#B91C1C"))
        phraseEt = EditText(this).apply { hint = "Type the sentence above" }
        emergency.addView(phraseEt)
        emergency.addView(button("Unlock now") {
            if (phraseEt.text.toString().trim().equals(phrase, ignoreCase = true)) {
                Prefs.setLockUntil(this, 0)
                phraseEt.setText("")
                render()
            } else {
                Toast.makeText(this, "Sentence doesn't match. Keep studying!", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(emergency)

        root.addView(button("Reset today's timer") {
            Prefs.setTodayMs(this, 0)
            render()
        }.apply { (layoutParams as? LinearLayout.LayoutParams) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        h.post(refresh)
    }

    override fun onPause() {
        h.removeCallbacks(refresh)
        super.onPause()
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        else
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        val ov = Settings.canDrawOverlays(this)
        val us = hasUsage()
        permTv.text = "${if (ov) "✅" else "❌"} Floating window    ${if (us) "✅" else "❌"} Usage access"
        btnOverlay.visibility = if (ov) View.GONE else View.VISIBLE
        btnUsage.visibility = if (us) View.GONE else View.VISIBLE
        toggleBtn.text = if (FocusService.running) "Stop floating timer" else "Start floating timer"
        timeTv.text = Prefs.fmt(Prefs.todayMs(this))

        val left = Prefs.lockUntil(this) - System.currentTimeMillis()
        if (left > 0) {
            lockTv.text = "🔒 Locked in — ${Prefs.fmt(left)} left"
            durRow.visibility = View.GONE
            emergency.visibility = View.VISIBLE
        } else {
            lockTv.text = "Block every other app for a set time."
            durRow.visibility = View.VISIBLE
            emergency.visibility = View.GONE
        }
    }

    private fun toggleService() {
        if (FocusService.running) {
            FocusService.stop(this)
            h.postDelayed({ render() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this) || !hasUsage()) {
            Toast.makeText(this, "Grant both permissions first", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        FocusService.start(this)
        h.postDelayed({ render() }, 300)
    }

    private fun startLock(min: Int) {
        if (!Settings.canDrawOverlays(this) || !hasUsage()) {
            Toast.makeText(this, "Grant both permissions first", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Lock in for $min min?")
            .setMessage("Only your study apps, the phone and the home screen will open. Everything else is blocked until time is up.")
            .setPositiveButton("Lock in") { _, _ ->
                if (!FocusService.running) FocusService.start(this)
                Prefs.setLockUntil(this, System.currentTimeMillis() + min * 60_000L)
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickApps() {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        val sel = Prefs.studyApps(this).toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in sel }
        AlertDialog.Builder(this)
            .setTitle("Study apps")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c ->
                if (c) sel.add(apps[i].first) else sel.remove(apps[i].first)
            }
            .setPositiveButton("Save") { _, _ -> Prefs.setStudyApps(this, sel) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
